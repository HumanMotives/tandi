# Botanica Refactor v0.1

Goal:
- Separate musical engine from UI.
- Keep browser version as reference.
- Prepare for a Max for Live implementation.

Planned structure:

engine/
    botanica-engine.js
    season.js
    blossom.js
    euclid.js

web/
    index.html
    style.css
    app.js
    botanica-reference.html   (original prototype)

m4l/
    botanica.maxpat
    botanica.js

assets/
    artwork
    fonts

Roadmap

Phase 1
- Extract sequencing engine.
- Browser UI still works.

Phase 2
- Connect same engine to Max for Live.

Phase 3
- Custom Botanica UI for M4L.
